from netgen.libngpy._stl import *
from .meshing import meshsize
