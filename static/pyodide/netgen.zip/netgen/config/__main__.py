from .config import get_cmake_dir

if __name__ == '__main__':
    print(get_cmake_dir())
